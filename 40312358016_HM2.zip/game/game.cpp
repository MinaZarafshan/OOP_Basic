#include "game.h"
#include "character.h"
#include <ctime>
#include <cstdlib>

Game::Game(){
    for(int i = 0 ; i<10 ; i++){
        characters[i] = {} ;
    }
    character_counter = 0 ;
}
Game::~Game(){}
void Game::add_character(){
    std::cout << "\nenter name: " ;
    std::string name ;
    std::cin >> name ;
    for( int i = 0 ; i< character_counter ; i++){
        if(name == characters[i]->character_name){
            std::cout << "this name is exist.try again!\n";
            return;
        }
    }
    characters[character_counter] = new Character( name );
    character_counter++ ;
    std::cout << "\ndone!\n"; 
}
void Game::print(){
    std::cout << "\nprint the list or any special chaarctor?(enter list or character's name)\n";
    std::string command;
    std::cin >> command;
    if(command == "list"){
        for(int i = 0 ; i < character_counter ; i++){
            for(int j = 0 ; j < 15 ; j++)
            std::cout << "name: " << characters[1]->character_name << std::endl << "health: " << characters[i]->character_health << std::endl << "power: "<<characters[i]->character_power << std::endl <<
            "score :"<< characters[i]->character_score << std::endl << "skill("<< j+1 <<") name: " <<characters[i]->character_skills[j].name << std::endl << "skill(" << j+1 << ")level: " << characters[i]->character_skills[j].lvl << std::endl ;
        }
        
    }
}

