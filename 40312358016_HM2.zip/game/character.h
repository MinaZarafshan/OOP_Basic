#ifndef CHARACTER_H
#define CHARACTER_H


#include <iostream>
#include <string>
struct skill{
    std::string name ;
    int lvl ;

};

class Character{
    public:
        std::string character_name ;
        int character_health , character_power ;
        skill character_skills [15] ;
        int character_skill_counter;
        int character_score ;

        Character( std::string name ) ;
        ~Character() ;
       


} ;










#endif 