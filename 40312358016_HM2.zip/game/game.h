#ifndef GAME_H
#define GAME_H
#include "character.h"

class Game{
    private:
        Character* characters[10] ;
        int character_counter ;
    
    public:
        Game() ;
        ~Game() ;
        void add_character();
        void print();
        void edit();


};



#endif