#include "character.h"

Character::Character(std::string name): character_health(10), character_power(1), character_score(0), character_name( name ), character_skill_counter(0){
    for( int i = 0 ; i < 15 ; i++ ){
        
        character_skills[i] = {} ;
    }
}




