#include "game.h"

int main(){
    Game my_game;
    std::cout << "welome!\n";
    bool flag ;
    while(flag){
        std::cout << "Enetr an item:\n1.add character\n2.print character's information\n3.exit\n";
        std::string command;

        std::cin >> command ;
        if(command == "add"){
            my_game.add_character();
        }
        else if(command == "print"){
            my_game.print();
        }
        else if(command == "exit"){
            break ;
        }
        else{
            std::cout << "\nthis item isnt exist!\ntry again: " ;
        }

    }
    

   
}