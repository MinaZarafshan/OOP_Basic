#include "sky.h"

Sky::Sky(){
    star_counter = 0 ;
    for(int i = 0 ; i<100 ; i++ ){
        stars[i] = nullptr ;
    }
}
Sky::~Sky(){}

void Sky::add_star(){
    std::cout << "\nwatch the sky with your telescope and then just write the coordinates\n";
    bool flag = true ;
    std::cout <<"enter x(1 < x <500): \n";
    int x, y, bright;
   
    while(flag){
        std::cin >> x;
        if(x >=1&& x <= 500 ){
            flag = false ;
        }
        else {
            std::cout << std::endl << "your number isnt in range! \ntry again :\n " ;
        }
        
    }
    flag = true ;
    std::cout << "\nenter y(1 < y <500): \n";
    while(flag){
        std::cin >> y;
        if(y >=1 && y <= 500){
            flag = false ;
        }
        else {
            std::cout << std::endl << "your number isnt in range! \ntry again :\n " ;
        }
    }
    flag = true ;
    std::cout << "\nenter brightness(1-10): \n";
    while(flag){
        std::cin >> bright;
        if(bright >= 1 && bright <= 10){
            flag = false;
        }
        else {
            std::cout << std::endl << "your number isnt in range! \ntry again :\n " ;
        }

    }
    
    stars[star_counter++]= new Star(x, y, bright) ;

    
    
}

void Sky::watch(){
    const int screenWidth = 500;
    const int screenHeight =500;
    InitWindow(screenWidth, screenHeight, "sky");
    SetTargetFPS(60);
    while (!WindowShouldClose()) {
        BeginDrawing();
        ClearBackground(BLACK);
        DrawText("Hello, Raylib on WSL!", 500, 1000, 20, GREEN);
        EndDrawing();
        for(int i = 0 ; i < star_counter ; i++){
            unsigned char glow = 100 + (stars[i]->bright * 15);
            Color glowColor = { 255, 255, 255, (unsigned char)glow};
            DrawCircle(stars[i]->xy.x, stars[i]->xy.y, 3, glowColor); 
        }
    }

    CloseWindow();

}
void Sky::show_in_terminal(){
    char arr[500][500]= {} ;
    for( int i = 0 ; i<star_counter ; i++){
        arr[stars[i]->xy.x][stars[i]->xy.y] = '*';

    }

    for(int i = 0 ; i < 500 ; i++ ){
        for(int j = 0 ; j < 500 ; j++ ){
            if(arr[i][j] != '*'){
               std::cout << " ";
            }
            else {
                std::cout << "*" ;
            }
            
        }
        std::cout << std::endl ;
        
    }
}   