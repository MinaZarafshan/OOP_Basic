#ifndef SKY_H
#define SKY_H
#include "star.h"

class Sky{
    private:
        int star_counter ;
        Star* stars[100];
    public:
        Sky();
        ~Sky();
        void add_star();
        void watch();
        void show_in_terminal();

};

#endif