#include "star.h"

Star::Star(int x, int y, int bright): bright(bright){
    xy.x=x;
    xy.y=y;
}
Star::~Star(){}