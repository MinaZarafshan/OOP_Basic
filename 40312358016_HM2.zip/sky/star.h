#ifndef STAR_H
#define STAR_H
#include <iostream>
#include <string>
#include "raylib.h"
struct XY{
    int x, y;
};

class Star{
    public:
    XY xy;
    int bright;
    Star(int x, int y, int bright);
    ~Star();
};

#endif