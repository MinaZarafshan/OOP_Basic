#include "sky.h"


int main(){

    Sky mini ;
    std::cout << "welcome to your sky :))))" ;
    bool flag = true;
    while(flag){
        std::cout <<"\nmenu:\n1.show sky\n2.add a star\n3.exit\n" ;
        std::string command;
        std::cin >> command;
        if(command == "show"){
            std::cout << "\nin terminal or a graphical window?(enter terminal or window)\n" ;
            std::string star;
            std::cin >> star ;
            if(star == "window"){
                mini.watch();
            }
            else if(star == "terminal"){
                mini.show_in_terminal();
            }
            else{
                std::cout << "\nthis item is not exist\ntry again\n." ;
            }
        }
        else if(command == "add"){
            mini.add_star();
        }
        else if(command == "exit"){
            flag = false;
        }
        else {
            std::cout << "\nthis item isnt exist!try again.\n";
        }

    }
    

    return 0;
}