#include "GPS.h"

GPS::GPS():prevlatitude(200) , prevlongitude(200){
    double lat ;
    bool flag = true ;
    while(flag){
        std::cout << "enter latitude:\n" ;
        std::cin >> lat ;
        while(lat < -90 || lat > 90){
            std::cerr << "latitude should be between -90 & 90.\n" ;
            std::cin >> lat ;
        }
        latitude = lat ;
        std::cout << "enter longitude:\n" ;
        double lon ;
        std::cin >> lon ;
        while(lon < -180 || lon > 180){
            std::cerr << "longitude should be between -180 & 180.\n" ;
            std::cin >>  lon ;
        }
        longitude = lon ;
        std::cout << "\ndo you want to enter new position?\n" ;
        std::string yesno ;
        std::cin >> yesno ;
        if(yesno == "yes"){
            prevlatitude = latitude ;
            prevlongitude = longitude ;
        }
        else if( yesno == "no"){
            flag = false ;
        }
    }
    


    
}



GPS::~GPS(){
    if(prevlatitude != 200 && prevlongitude != 200){
        std::cout << "last position:\nLatitude: " << prevlatitude << "\nLongitude: " << prevlongitude << std::endl ;
    }
    
}
void GPS::update(){
    prevlongitude = longitude ;
    prevlatitude = latitude ;
    double lat ;
    std::cin >> lat ;
    while(lat < -90 || lat > 90){
        std::cerr << "latitude should be between -90 & 90.\n" ;
        std::cin >> lat ;
        }
    latitude = lat ;
    std::cout << "enter longitude:\n" ;
    double lon ;
    std::cin >> lon ;
    while(lon < -180 || lon > 180){
            std::cerr << "longitude should be between -180 & 180.\n" ;
            std::cin >>  lon ;
    }
    longitude = lon ;

}
