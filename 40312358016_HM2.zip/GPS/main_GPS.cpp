#include "GPS.h"

int main(){
    bool flag = true ;
    std:: cout << "welcome!\n" ;
    while(flag){
        
        std::cout << "if you want to exit from program just enter (exit) else , enter continue.\n" ;
        std::string command ;
        std::cin >>  command ;
        if(command == "exit" ){
            flag = false ;
        }
        else if( command == "continue" ){
            
            GPS gps ;
            
            
            
        }
        
    }
    return 0 ;
}