#ifndef GPS_H
#define GPS_H

#include <iostream>
#include <string>

class GPS{
    private:
        double latitude ;
        double longitude ;
        double prevlatitude ;
        double prevlongitude ;
    public:
        GPS() ;
        ~GPS() ;
        void update() ;
        
};




#endif 