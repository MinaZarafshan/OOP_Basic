HM2 - OOP Basic

GitHub Repository Link:

https://github.com/MinaZarafshan/OOP_Basics.git