#include "hospital.h"

int main(){
    Hospital Mashad ;
    std::cout << "welcome!\n";
    bool flag = true;
    while(flag){
        std::cout << "\nwhich item:\n1.add patient.\n2.edit patients information.\n3.print patients health.\n4.exit.\n";
        std::string command;
        std::cin >> command;
        if(command == "add"){
            Mashad.add();
        }
        else if(command == "edit"){
            Mashad.edit();
        }
        else if(command == "print"){
            Mashad.print();
        }
        else if(command == "exit" ){
            flag = false;
        }
    }

}