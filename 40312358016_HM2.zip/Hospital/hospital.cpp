#include "hospital.h"
#include "patient.h"
#include <ctime>
#include <cstdlib>

Hospital::Hospital():patient_counter(0){
    for(int i = 0 ; i < 100 ; i++){
        patients[i] = {};
    }
}

Hospital::~Hospital(){}
void Hospital::add(){
    
    std::cout << "\nenter patient's name: ";
    std::string name ;
    std::cin >> name;
    std::cout << "\nenter patient's lastname: ";
    std::string lastname ;
    std::cin >> lastname;
    srand(time(0)) ;
    long int id = rand() % 1000000 ;
    std::cout << "\npatient's id: " << id ;
    std::cout << "\nMeasure " << lastname << "'s fever then enter it: ";
    float temp;
    std::cin >> temp;
    std::cout << "\nMeasure " << lastname << "'s heart rate then enter the number: ";
    int heart_rate;
    std::cin >> heart_rate;
    std::cout << "\nMeasure " << lastname << "'s respiratory rate(per minute) then enter it: ";
    int respiratory ;
    std::cin >>  respiratory;
    std::cout << "\nMeasure " << lastname << "'s blood pressure then enter it: ";
    float blood_pressure;
    std::cin >> blood_pressure;
    patients[patient_counter] = new Patient( name, lastname, temp, heart_rate, respiratory, blood_pressure, id );

    std::cout << "\nchecking the patient's health..." ;

    if ( patients[patient_counter]->temp > 36 && patients[patient_counter]->temp < 37.5 ){
        std::cout << std::endl <<patients[patient_counter]->lastname << "'s fever: " <<  patients[patient_counter]->temp;
        std::cout << "\nThe patient's fever is within the normal range.";
    }
    else {
        std::cout << "\nThe patient's fever is out of normal range!!";
    }

    if ( patients[patient_counter]->heart_rate > 60 && patients[patient_counter]->heart_rate < 100 ){
        std::cout << "\nThe patinet's heart rate is within the normal range.";
    }
    else {
        std::cout << "\nThe patient's heart rate is out of normal range!!";
    }

    if ( patients[patient_counter]->respiratory > 16 && patients[patient_counter]->respiratory < 20){
        std::cout << "\nThe patinet's respiratory is within the normal range.";
    }
    else {
        std::cout << "\nThe patient's respiratory is out of normal range!!";
    }

    if ( patients[patient_counter]->blood_pressure > 80 && patients[patient_counter]->blood_pressure < 100 ){
        std::cout << "\nThe patinet's blood pressure is within the normal range.";
    }
    else {
        std::cout << "\nThe patient's blood pressure is out of normal range!!";
    }
    patient_counter++;


 }

void Hospital::edit(){
    std::cout << "\nwhich patient's information do you want to edit?(enter the id)" ;
    long int id ;
    for ( int i = 0 ; i < patient_counter ; i++ ){
        if( patients[i]->heart_rate == id ){
            std::cout << "\nName: " << patients[i]->name << "\nLastname: " << patients[i]->lastname << "\nID: " << patients[i]->id << "\nTempreture: " << patients[i]->temp << "\nRespiratory: " << patients[i]->respiratory << "\n Heart rate: " << 
            patients[i]->heart_rate << "\nBlood Pressure: " << patients[i]->blood_pressure << std::endl <<"Which item do you want to change?(Write in lowercase letters.You cant change name , lastname and id) \n";
            std::string command;
            getline(std::cin , command );
            std::cout << "enetr new " << command;
            double new_item;
            std::cin >> new_item;
            if(command == "tempreture" ){
                patients[i]->temp = (float)new_item;
            }
            else if(command == "respiratory" ){
                patients[i]->respiratory = (int)new_item;
            }
            else if(command == "heart rate" || command == "heart_rate"){
                patients[i]->heart_rate = (int)new_item;
            }
            else if(command == "blood pressure" || command == "blood_pressure"){
                patients[i]->blood_pressure = (float)new_item;
            }
            else { 
                std::cout << "\nthis item isnt exist ;try again." ;
            }
        }
    }
}
void Hospital::print(){
        std::cout << "\nany special patient or print the whole list?(enter list or special) \n";
        std::string command;
        std::cin >> command;
        if(command == "list"){
            for(int i = 0 ; i < patient_counter ; i++){
                std::cout << "\nName: " << patients[i]->name << "\nLastname: " << patients[i]->lastname << "\nID: " << patients[i]->id << "\nTempreture: " << patients[i]->temp << "\nRespiratory: " << patients[i]->respiratory << "\nHeart rate: " << 
                patients[i]->heart_rate << "\nBlood Pressure: " << patients[i]->blood_pressure <<std::endl<< std::endl;
            
            }
        }
        else if(command == "special"){
            std::cout << "enter patient's id : ";
            long int inform;
            std::cin >> inform ;
            for (int i = 0 ; i < patient_counter ; i++ ){
                if(patients[i]->id == inform ){
                    std::cout << "\nName: " << patients[i]->name << "\nLastname: " << patients[i]->lastname << "\nID: " << patients[i]->id << "\nTempreture: " << patients[i]->temp << "\nRespiratory: " << patients[i]->respiratory << "\nHeart rate: " << 
                    patients[i]->heart_rate << "\nBlood Pressure: " << patients[i]->blood_pressure << std::endl;
                }
            }


        }
        else{
            std::cout << "\nitem you entered isnt exist!\n";
        }
    
}