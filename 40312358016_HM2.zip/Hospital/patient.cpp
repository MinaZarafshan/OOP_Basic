#include "patient.h"

Patient::Patient(std::string name, std::string lastname , float temp, int heart_rate, int respiratory, float blood_pressure, long int id ):name(name) , lastname(lastname), temp(temp), 
heart_rate(heart_rate), respiratory(respiratory), blood_pressure(blood_pressure), id(id){}
Patient::~Patient(){}
