#ifndef HOSPITAL_H
#define HOSPITAL_H

#include "patient.h"

class Hospital{

    private:
        Patient* patients[100] ;
        int patient_counter ;
    
    public:
        Hospital() ;
        ~Hospital() ;
        void add();
        void edit();
        void print() ;

};


#endif