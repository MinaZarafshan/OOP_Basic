#ifndef PATIENT_H
#define PATIENT_H

#include <iostream>
#include <string>

class Patient{
    public:
        std::string name ;
        std::string lastname ;
        float temp ;
        int heart_rate ;
        int respiratory ;
        float blood_pressure;
        long int id ;
        Patient( std::string name, std::string lastname , float temp, int heart_rate, int respiratory, float blood_pressure, long int id ) ;
        ~Patient() ;
};

#endif 