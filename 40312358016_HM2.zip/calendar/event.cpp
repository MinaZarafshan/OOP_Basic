#include "event.h"

Event::Event(const std::string& name , time_t start , time_t end)
: event_name(name), event_start(start), event_end(end) {}

Event::~Event(){
    std::cout<<std::endl << "Event (" << event_name << ") has been deleted successfully!"<< std::endl ;
}