#include "calendar.h"

Calendar::Calendar():event_counter(0){
    for(int i = 0 ; i<100 ; i++){
        events[i] = {} ;
    }
}

Calendar::~Calendar(){
    for(int i = 0 ;i<100 ; i++){
        delete events[i] ;
    }
}

void Calendar::add_event(const std::string& name , time_t start , time_t end ){
    for(int i = 0 ; i <event_counter ; i++){
        if(start < events[i]->event_end && end > events[i]->event_start ){
            std::cout << name << " overlaps with " <<events[i]->event_name << std::endl ;
            return ;
        }
    }

    if(event_counter < 100){
        events[event_counter++] = new Event(name , start , end) ;
    }else {
        std::cout << "the calendar is full!!\n" ;
    }
}

void Calendar::print(){
    for(int i = 0 ; i<event_counter ; i++){
        std::cout << std::endl << "Event " << i+1 << " : " << events[i]->event_name << "." << std::endl ;
    }
} 
void Calendar::refresh(){
    time_t now = time(nullptr);
    
    for(int i = 0 ; i<event_counter ; i++){
    
        if(events[i]->event_end<now){
            std::cout <<std::endl << "Event " <<events[i]->event_name <<" has been expired. Removing is beeing done.\n" ;
            delete events[i] ;
            for(int j = i ; j<event_counter ; j++){
                events[j]=events[j+1] ;
            }
            events[event_counter--] = nullptr ;
            i-- ;
        }
    }
}