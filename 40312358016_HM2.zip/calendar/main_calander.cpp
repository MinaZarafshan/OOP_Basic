#include "calendar.h"

int main(){
    Calendar event ;
    bool flag = true ;
    while(flag){
        std::cout << "\nenter your command: \n1.enter event \n2.print event \n3.refresh\n4.exit\n(enter just the first word)\n"  ;
        std::string command ;
        std::cin >> command ;
        if(command == "enter"){
            time_t now = time(nullptr) ;
            
            std::string name ;
            int start , end ;
            std::cout << "enter event name: \n" ;
            std::cin >> name ;
            std::cout << "enter the start of the item(by sec)\neach 1 min = 60 sec\neach hour = 3600 sec: \n" ;
            std::cin >> start ;
            std::cout << "enter the end of the item(by sec)\neach 1 min = 60 sec\neach hour = 3600 sec: \n" ;
            std::cin >> end ;
            event.add_event(name, start+now, end+now) ;
        }
        else if(command == "print"){
            event.print();
        }
        else if(command == "refresh"){
            event.refresh() ;
        }
        else if(command == "exit"){
            flag = false ;
        }
        else{
            std::cout << "\nThis item isnt exist. Try again or exit.\n" ;
        }
    }
    
    



    return 0 ;
}