#ifndef EVENT_H
#define EVENT_H
#include <iostream>
#include <ctime>
#include <string>



class Event{
    public:
        std::string event_name ;
        time_t event_start ;
        time_t event_end ;

        Event(const std::string& name , time_t start , time_t end ) ;
        ~Event() ;

};


#endif EVENT_H