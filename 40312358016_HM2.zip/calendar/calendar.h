#ifndef CALENDAR_H
#define CALENDAR_H
#include "event.h"



class Calendar{
    private:
        Event* events[100] ;
        int event_counter ;
    public:
        Calendar() ;
        ~Calendar() ;
        void print() ;
        void add_event(const std::string& event_name , time_t event_start , time_t event_end ) ;
        void refresh() ;

        
};



#endif CALENDAR_H